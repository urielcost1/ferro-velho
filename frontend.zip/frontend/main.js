import { trocarTela } from './core.js';
import { carregarMateriais, editarMaterial, deletarMaterial } from './materiais.js';
import { calcularValor, adicionarEntrada, atualizarListaEntradas, configurarCalculoDinamico } from './entradas.js';
import { enviarPedido, carregarPedidos } from './pedidos.js';

// 🔁 Exportar globalmente funções necessárias para onclicks em HTML
window.trocarTela = trocarTela;
window.editarMaterial = editarMaterial;
window.deletarMaterial = deletarMaterial;

// ✅ Inicialização
document.addEventListener('DOMContentLoaded', () => {
  carregarMateriais();
  carregarPedidos();
  configurarCalculoDinamico();

  // Botão "Adicionar Entrada"
  document.getElementById('adicionarEntrada').addEventListener('click', adicionarEntrada);

  // Botão "Finalizar Pedido" (submissão do form)
  document.getElementById('entradaForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    await enviarPedido();
  });
});
